// Popup 控制脚本

let isRunning = false;

// 日志函数
function log(message, type = 'info') {
  const container = document.getElementById('logContainer');
  const entry = document.createElement('div');
  entry.className = `log-entry ${type}`;
  entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  container.appendChild(entry);
  container.scrollTop = container.scrollHeight;
}

// 获取当前活动标签页
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

// 检查页面状态
async function checkPageStatus() {
  const tab = await getCurrentTab();
  const pageStatus = document.getElementById('pageStatus');

  const url = tab.url || '';

  // 支持 yooc.me、localhost 和 file://
  const isYooc = url.includes('yooc.me');
  const isLocalhost = url.includes('localhost') || url.includes('127.0.0.1');
  const isFile = url.startsWith('file://');

  if (isYooc || isLocalhost || isFile) {
    pageStatus.textContent = '✓ 可使用';
    pageStatus.className = 'status-value success';
    document.getElementById('startBtn').disabled = false;
    return true;
  } else {
    pageStatus.textContent = '非目标网站';
    pageStatus.className = 'status-value error';
    document.getElementById('startBtn').disabled = true;
    return false;
  }
}

// 发送消息到 content script
async function sendMessage(action, data = {}) {
  const tab = await getCurrentTab();
  try {
    const response = await chrome.tabs.sendMessage(tab.id, { action, ...data });
    return response;
  } catch (e) {
    log(`通信错误: ${e.message}`, 'error');
    return null;
  }
}

// 开始自动答题
async function startAutoAnswer() {
  const delay = parseInt(document.getElementById('delay').value) || 800;
  const autoNext = document.getElementById('autoNext').checked;

  log('开始自动答题...');
  isRunning = true;

  document.getElementById('startBtn').style.display = 'none';
  document.getElementById('stopBtn').style.display = 'block';

  const response = await sendMessage('START_AUTO_ANSWER', { delay, autoNext });

  if (response && response.success) {
    log(`答题完成! 正确: ${response.answered}/${response.total}`, 'success');
  } else if (response && response.error) {
    log(`错误: ${response.error}`, 'error');
  }

  isRunning = false;
  document.getElementById('startBtn').style.display = 'block';
  document.getElementById('stopBtn').style.display = 'none';
}

// 停止自动答题
async function stopAutoAnswer() {
  await sendMessage('STOP_AUTO_ANSWER');
  isRunning = false;
  log('已停止');
  document.getElementById('startBtn').style.display = 'block';
  document.getElementById('stopBtn').style.display = 'none';
}

// 答当前题
async function answerCurrentQuestion() {
  log('正在匹配当前题目...');
  const response = await sendMessage('ANSWER_CURRENT');

  if (response && response.success) {
    log(`已选择: ${response.answer}`, 'success');
  } else if (response && response.error) {
    log(`错误: ${response.error}`, 'error');
  } else if (response && response.notFound) {
    log('未找到匹配的题目', 'warning');
  }
}

// 更新进度显示
async function updateProgress() {
  const response = await sendMessage('GET_PROGRESS');
  if (response) {
    document.getElementById('progressStatus').textContent =
      `${response.current || '-'} / ${response.total || '-'}`;
  }
}

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
  // 检查页面状态
  await checkPageStatus();
  await updateProgress();

  // 绑定按钮事件
  document.getElementById('startBtn').addEventListener('click', startAutoAnswer);
  document.getElementById('stopBtn').addEventListener('click', stopAutoAnswer);
  document.getElementById('answerOneBtn').addEventListener('click', answerCurrentQuestion);

  // 定时更新进度
  setInterval(updateProgress, 2000);

  log('插件已就绪');
});
