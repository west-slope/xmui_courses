// Content Script - 形策自动答题助手 v2.0.0 (25-26第二学期)
// 支持标准input和自定义选项元素

const VERSION = '2.0.0';
console.log(`[形策助手] v${VERSION} 已加载`);

let isRunning = false;
let shouldStop = false;

// ================== 浮动面板 UI ==================
function createFloatingPanel() {
    if (document.getElementById('xc-helper-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'xc-helper-panel';
    panel.innerHTML = `
    <style>
      #xc-helper-panel {
        position: fixed;
        top: 10px;
        right: 10px;
        width: 300px;
        max-height: 480px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 12px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        z-index: 999999;
        font-family: -apple-system, sans-serif;
        overflow: hidden;
        font-size: 13px;
      }
      #xc-helper-panel .hdr {
        padding: 10px 14px;
        background: rgba(0,0,0,0.2);
        display: flex;
        justify-content: space-between;
        cursor: move;
      }
      #xc-helper-panel .hdr span { font-weight: 600; }
      #xc-helper-panel .close-btn {
        background: none; border: none; color: white;
        font-size: 18px; cursor: pointer;
      }
      #xc-helper-panel .content { padding: 10px 14px; max-height: 180px; overflow-y: auto; }
      #xc-helper-panel .match-box {
        background: rgba(255,255,255,0.15);
        border-radius: 8px;
        padding: 8px;
        margin-bottom: 8px;
        font-size: 12px;
      }
      #xc-helper-panel .answer-box {
        background: rgba(74, 222, 128, 0.4);
        border-radius: 6px;
        padding: 8px;
        font-size: 15px;
        font-weight: bold;
        text-align: center;
      }
      #xc-helper-panel .btns { padding: 8px 14px 12px; }
      #xc-helper-panel .btn {
        width: 100%; padding: 9px; border: none; border-radius: 6px;
        font-size: 13px; font-weight: 600; cursor: pointer; margin-top: 6px;
      }
      #xc-helper-panel .btn-w { background: white; color: #764ba2; }
      #xc-helper-panel .btn-g { background: #4ade80; color: #166534; }
      #xc-helper-panel .btn-r { background: #f87171; color: white; display: none; }
      #xc-helper-panel .log-box {
        max-height: 90px; overflow-y: auto;
        background: rgba(0,0,0,0.2);
        border-radius: 6px; padding: 6px; margin-top: 8px;
        font-size: 11px; font-family: monospace;
      }
      #xc-helper-panel .delay-row {
        display: flex; align-items: center; gap: 8px; margin-bottom: 8px;
      }
      #xc-helper-panel .delay-row input {
        width: 50px; padding: 4px; border: none; border-radius: 4px;
      }
    </style>
    <div class="hdr">
      <span>🎓 形策助手 v${VERSION}</span>
      <button class="close-btn" id="xc-close">×</button>
    </div>
    <div class="content" id="xc-content">
      <div id="xc-match">点击查看按钮显示匹配结果</div>
    </div>
    <div class="btns">
      <div class="delay-row">
        <label>延迟:</label>
        <input type="number" id="xc-delay" value="1500" min="500" max="10000" step="100">
        <span style="font-size:11px;opacity:0.7">ms+随机</span>
      </div>
      <button class="btn btn-w" id="xc-view">🔍 查看答案</button>
      <button class="btn btn-w" id="xc-one">✓ 选当前题</button>
      <button class="btn btn-g" id="xc-auto">▶ 自动答题</button>
      <button class="btn btn-r" id="xc-stop">⏹ 停止</button>
      <div class="log-box" id="xc-log"></div>
    </div>
  `;

    document.body.appendChild(panel);

    // 创建恢复按钮（最小化时显示）
    const restoreBtn = document.createElement('div');
    restoreBtn.id = 'xc-restore-btn';
    restoreBtn.innerHTML = '🎓';
    restoreBtn.style.cssText = `
    position: fixed; top: 10px; right: 10px; width: 40px; height: 40px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-radius: 50%; display: none; cursor: pointer; z-index: 999999;
    font-size: 20px; line-height: 40px; text-align: center;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
  `;
    restoreBtn.title = '打开形策助手';
    document.body.appendChild(restoreBtn);

    // 关闭按钮 - 最小化面板
    document.getElementById('xc-close').onclick = () => {
        panel.style.display = 'none';
        restoreBtn.style.display = 'block';
    };

    // 恢复按钮 - 显示面板
    restoreBtn.onclick = () => {
        panel.style.display = 'block';
        restoreBtn.style.display = 'none';
        showMatch(); // 恢复时刷新显示
    };

    document.getElementById('xc-view').onclick = () => showMatch();

    document.getElementById('xc-one').onclick = async () => {
        log('选择答案...');
        const r = await answerCurrent();
        showMatch();
        log(r.success ? `✓ ${r.answer}` : `✗ ${r.error || '未找到'}`);
    };

    document.getElementById('xc-auto').onclick = async () => {
        document.getElementById('xc-auto').style.display = 'none';
        document.getElementById('xc-stop').style.display = 'block';

        const delayMs = parseInt(document.getElementById('xc-delay').value) || 1500;
        log(`🚀 开始 (${delayMs}ms+随机)...`);

        const r = await autoAnswer({ delayMs });

        document.getElementById('xc-auto').style.display = 'block';
        document.getElementById('xc-stop').style.display = 'none';

        if (r.success) log(`🎉 完成! ${r.answered}/${r.answered + r.failed}`);
    };

    document.getElementById('xc-stop').onclick = () => {
        shouldStop = true;
        log('⏹ 停止');
    };

    // 拖动
    const hdr = panel.querySelector('.hdr');
    let ox, oy;
    hdr.onmousedown = e => {
        ox = e.clientX - panel.offsetLeft;
        oy = e.clientY - panel.offsetTop;
        document.onmousemove = e => {
            panel.style.left = (e.clientX - ox) + 'px';
            panel.style.top = (e.clientY - oy) + 'px';
            panel.style.right = 'auto';
        };
        document.onmouseup = () => document.onmousemove = null;
    };
}

function log(msg) {
    const el = document.getElementById('xc-log');
    if (el) {
        const t = new Date().toLocaleTimeString('zh-CN', { hour12: false });
        el.innerHTML += `<div>[${t}] ${msg}</div>`;
        el.scrollTop = el.scrollHeight;
    }
    console.log('[形策助手]', msg);
}

let lastQuestionText = '';

function showMatch() {
    const el = document.getElementById('xc-match');
    if (!el) return;

    const { questionText, progress } = getQuestion();

    if (!questionText) {
        el.innerHTML = '<div style="color:#fca5a5">⚠️ 无法读取题目</div>';
        return;
    }

    const m = findAnswer(questionText);

    if (m) {
        const score = similarity(questionText, m.question);

        // 获取答案选项文本
        const answerKeys = m.answer.split('');
        let answerTexts = '';
        for (const key of answerKeys) {
            const opt = m.options.find(o => o.key === key);
            if (opt) {
                answerTexts += `<div style="margin:2px 0;font-size:11px"><b>${key}.</b> ${opt.text}</div>`;
            }
        }

        el.innerHTML = `
      <div class="match-box" style="font-size:11px">
        <div style="color:#86efac;margin-bottom:4px">📚 题库 [第${m.id}题] (${Math.round(score * 100)}%匹配)</div>
        <div>${m.question.substring(0, 100)}${m.question.length > 100 ? '...' : ''}</div>
      </div>
      <div class="answer-box" style="text-align:left">
        <div style="font-size:14px;font-weight:bold;margin-bottom:6px">✅ 答案: ${m.answer} (${m.type === 'multi' ? '多选' : '单选'})</div>
        ${answerTexts}
      </div>
    `;
    } else {
        el.innerHTML = `
      <div style="color:#fca5a5;text-align:center;padding:8px">❌ 题库中未找到匹配</div>
    `;
    }
}

// 自动检测题目变化并更新显示
function startAutoUpdate() {
    setInterval(() => {
        const { questionText } = getQuestion();
        if (questionText && questionText !== lastQuestionText) {
            lastQuestionText = questionText;
            showMatch();
        }
    }, 500); // 每500ms检测一次
}

setTimeout(() => {
    createFloatingPanel();
    startAutoUpdate(); // 启动自动更新
}, 1000);

// ================== 核心逻辑 ==================

const delay = ms => new Promise(r => setTimeout(r, ms));
const randDelay = base => delay(base + Math.random() * 1000);

function getQuestion() {
    let questionText = '';
    let progress = { current: 0, total: 0 };

    // 查找题目
    const els = document.querySelectorAll('h1,h2,h3,h4,p,div,span');
    for (const el of els) {
        const t = el.textContent.trim();
        const m = t.match(/^\d+[、.．]\s*[\[【]?\d*分?[\]】]?\s*(.{10,})/);
        if (m && !t.includes('上一') && !t.includes('下一')) {
            questionText = m[1].replace(/[A-E][.、．].*/s, '').trim();
            if (questionText.length > 15) break;
        }
    }

    // 进度
    const pm = document.body.innerText.match(/(\d+)\s*[\/／]\s*(\d+)/);
    if (pm) {
        progress.current = parseInt(pm[1]);
        progress.total = parseInt(pm[2]);
    }

    return { questionText, progress };
}

// ============ 点击选项 - 针对yooc.me优化 ============
async function clickOption(key) {
    console.log('[形策助手] 选择:', key);

    // 方法1: yooc.me 专用 - 点击 li 元素
    const liElements = document.querySelectorAll('li');
    let bestLi = null;
    let bestLen = Infinity;

    for (const li of liElements) {
        const text = li.textContent.trim();
        const pattern = new RegExp(`^${key}[.、．\\s]`);
        if (pattern.test(text)) {
            if (text.length < bestLen) {
                bestLen = text.length;
                bestLi = li;
            }
        }
    }

    if (bestLi) {
        console.log('[形策助手] ✓ 点击选项', key);

        // 完整的鼠标事件序列（用于React/Vue框架）
        const rect = bestLi.getBoundingClientRect();
        const x = rect.left + rect.width / 2;
        const y = rect.top + rect.height / 2;

        const mouseOpts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };

        bestLi.dispatchEvent(new MouseEvent('mousedown', mouseOpts));
        await delay(50);
        bestLi.dispatchEvent(new MouseEvent('mouseup', mouseOpts));
        await delay(50);
        bestLi.dispatchEvent(new MouseEvent('click', mouseOpts));

        await delay(200);
        return true;
    }

    // 方法2: 尝试标准 input
    const inputs = document.querySelectorAll('input[type="radio"], input[type="checkbox"]');
    if (inputs.length > 0) {
        const idx = key.charCodeAt(0) - 65; // A=0
        if (idx >= 0 && idx < inputs.length) {
            const inp = inputs[idx];
            inp.focus && inp.focus();
            inp.click();
            inp.checked = true;
            inp.dispatchEvent(new Event('change', { bubbles: true }));
            console.log('[形策助手] ✓ 通过input索引');
            await delay(100);
            return true;
        }
    }

    // 方法2: 查找选项容器 - 更精确的筛选
    console.log('[形策助手] 尝试点击选项容器...');

    // 只查找可能是选项的元素类型
    const allEls = document.querySelectorAll('label, li, div[class*="option"], div[class*="choice"], div[class*="answer"], p, span');
    const optionEls = [];

    for (const el of allEls) {
        const t = el.textContent.trim();
        // 精确匹配选项格式
        if (t.match(/^[A-E][.、．]/) && t.length > 2 && t.length < 150) {
            // 检查是否是最小匹配元素（不包含其他选项）
            const allOptions = t.match(/[A-E][.、．]/g) || [];
            if (allOptions.length === 1) {
                // 检查子元素中是否有更小的匹配
                let isSmallest = true;
                for (const child of el.children) {
                    if (child.textContent.trim().match(/^[A-E][.、．]/)) {
                        isSmallest = false;
                        break;
                    }
                }
                if (isSmallest) {
                    optionEls.push({ el, text: t, key: t.charAt(0) });
                }
            }
        }
    }

    // 去重 - 保留最小（最内层）的元素
    const uniqueOptions = [];
    for (const opt of optionEls) {
        const isDuplicate = uniqueOptions.some(u =>
            u.key === opt.key && (u.el.contains(opt.el) || opt.el.contains(u.el))
        );
        if (!isDuplicate) {
            uniqueOptions.push(opt);
        }
    }

    console.log('[形策助手] 找到', uniqueOptions.length, '个选项');

    // 找到对应选项
    const target = uniqueOptions.find(o => o.key === key);
    if (target) {
        console.log('[形策助手] 点击:', target.text.substring(0, 40));
        await clickElement(target.el);
        return true;
    }

    // 方法3: 通过索引
    const idx = key.charCodeAt(0) - 65;
    // 按key排序后取第idx个
    uniqueOptions.sort((a, b) => a.key.localeCompare(b.key));
    if (idx >= 0 && idx < uniqueOptions.length) {
        console.log('[形策助手] 通过排序索引点击');
        await clickElement(uniqueOptions[idx].el);
        return true;
    }

    console.log('[形策助手] ✗ 未找到选项');
    return false;
}

// 点击元素 - 尝试多种方式
async function clickElement(el) {
    // 先尝试点击元素本身
    el.focus && el.focus();
    el.click();

    // 触发多种事件
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
    el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));

    // 检查内部是否有可点击元素
    const innerClickable = el.querySelector('input, button, a, [onclick]');
    if (innerClickable) {
        innerClickable.click();
        if (innerClickable.type === 'radio' || innerClickable.type === 'checkbox') {
            innerClickable.checked = true;
            innerClickable.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }

    // 尝试点击父元素
    if (el.parentElement && el.parentElement.tagName !== 'BODY') {
        el.parentElement.click();
    }

    await delay(100);
    console.log('[形策助手] ✓ 点击完成');
}

// 点击下一题
async function clickNext() {
    const els = document.querySelectorAll('button, a, div, span');
    for (const el of els) {
        const t = el.textContent.trim();
        if (t === '下一题' || (t.includes('下一') && t.length < 6)) {
            el.click();
            console.log('[形策助手] 下一题');
            return true;
        }
    }
    return false;
}

// 答当前题
async function answerCurrent() {
    const { questionText } = getQuestion();
    if (!questionText || questionText.length < 10) {
        return { success: false, error: '无法获取题目' };
    }

    const m = findAnswer(questionText);
    if (!m) return { success: false, notFound: true };

    const keys = m.answer.split('');
    console.log('[形策助手] 答案:', m.answer, '共', keys.length, '个选项');

    let ok = 0;
    for (let i = 0; i < keys.length; i++) {
        const k = keys[i];
        console.log('[形策助手] 正在选择第', i + 1, '个选项:', k);
        const result = await clickOption(k);
        if (result) {
            ok++;
            console.log('[形策助手] ✓ 选项', k, '已选择');
        } else {
            console.log('[形策助手] ✗ 选项', k, '选择失败');
        }
        await delay(300); // 增加延迟
    }

    console.log('[形策助手] 完成，成功选择', ok, '/', keys.length);
    return ok > 0 ? { success: true, answer: m.answer } : { success: false, error: '点击失败' };
}

// 自动答题
async function autoAnswer(opts = {}) {
    const { delayMs = 2000 } = opts;

    if (isRunning) return { success: false, error: '运行中' };
    isRunning = true;
    shouldStop = false;

    let answered = 0, failed = 0;

    try {
        while (!shouldStop) {
            await delay(400); // 等页面稳定

            const { progress } = getQuestion();
            const cur = progress.current || (answered + failed + 1);
            const total = progress.total || 50;

            log(`📝 ${cur}/${total}...`);

            const r = await answerCurrent();
            if (r.success) {
                answered++;
                log(`✓ ${r.answer}`);
            } else {
                failed++;
                log(`⚠ ${r.error || '未匹配'}`);
            }

            if (cur >= total) {
                log('🎉 全部完成，请提交!');
                break;
            }

            log('⏳ 等待...');
            await randDelay(delayMs);

            log('➡️ 下一题');
            if (!await clickNext()) {
                log('找不到下一题');
                break;
            }
            await delay(800);
        }
    } catch (e) {
        console.error(e);
        log('错误: ' + e.message);
    } finally {
        isRunning = false;
    }

    return { success: true, answered, failed };
}

// 消息监听
chrome.runtime.onMessage.addListener((req, sender, res) => {
    switch (req.action) {
        case 'START_AUTO_ANSWER': autoAnswer(req).then(res); return true;
        case 'STOP_AUTO_ANSWER': shouldStop = true; res({ ok: 1 }); break;
        case 'ANSWER_CURRENT': answerCurrent().then(res); return true;
        case 'GET_PROGRESS': res(getQuestion().progress); break;
    }
});

console.log('[形策助手] 题库:', QUESTION_BANK.length, '题');
